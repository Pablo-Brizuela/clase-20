const express = require("express");
const productos = require("./data/productsDataBase.json");

const app = express();
app.use(express.static("public"));

app.set("view engine", "ejs");

app.get("/", (req, res) => {
  /**
   * logica
   */
  const oferta = productos.filter((elemento) => elemento.category == "in-sale");

  const visita = productos.filter((elemento) => elemento.category == "visited");

  res.render("home", { oferta: oferta, visita: visita });
});

// app.get("/login", (req, res) => {
//   res.sendFile(__dirname + "/views/login.html");
// });

// app.get("/register", (req, res) => {
//   res.sendFile(__dirname + "/views/register.html");
// });

// for (let index = 0; index < productos.length; index++) {
//   console.log(productos[index]);
// }

// productos.forEach((p) => {
//   console.log(p);
// });

// for (const p of productos) {

//   console.log(p);
// }

app.listen(3001, () => {
  console.log("Servidor funcionando");
});
